import { JupyterFrontEndPlugin } from '@jupyterlab/application';
/**
 * Initialization data for the main menu example.
 */
declare const extension: JupyterFrontEndPlugin<void>;
export default extension;
